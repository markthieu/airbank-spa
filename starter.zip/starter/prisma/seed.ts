import { PrismaClient, Prisma } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
    console.log(`Start seeding ...`);
    // Create temp tables
    await prisma.$executeRaw(Prisma.sql`CREATE temp TABLE new_Account(like "SCHEMA"."Account");`);
    await prisma.$executeRaw(Prisma.sql`CREATE temp TABLE new_Category(like "SCHEMA"."Category");`);
    await prisma.$executeRaw(Prisma.sql`CREATE temp TABLE new_Transaction(like "SCHEMA"."Transaction");`);
    // Fill temp tables
    await prisma.$executeRaw(Prisma.sql`COPY new_Account
         FROM './prisma/data/accounts.csv'
          with null as E'''' DELIMITER ',' CSV HEADER;`);
    await prisma.$executeRaw(Prisma.sql`COPY new_Category
         FROM './prisma/data/categories.csv'
          with null as E'''' DELIMITER ',' CSV HEADER;`);
    await prisma.$executeRaw(Prisma.sql`COPY new_Transaction("id","accountId", "categoryId", "reference",  "amount", "currency", "date")
         FROM './prisma/data/transactions.csv'
          with null as E'''' DELIMITER ',' CSV HEADER;`);
    // Set tables to temp tables
    await prisma.$executeRaw(Prisma.sql`INSERT INTO "SCHEMA"."Account"(id, name)
SELECT id, name
FROM new_Account
WHERE id not in (SELECT ID from "SCHEMA"."Account");`);
    await prisma.$executeRaw(Prisma.sql`INSERT INTO "SCHEMA"."Category"(id, name, color)
SELECT id, name, color
FROM new_Category
WHERE id not in (SELECT ID from "SCHEMA"."Category");`);
    const tx = await prisma.$executeRaw(Prisma.sql`insert into "SCHEMA"."Transaction" (id, "accountId", "categoryId", reference, amount, currency, date)
                                                   select nt.id, a.id, c.id, nt.reference, nt.amount, nt.currency, nt.date
                                                   from new_Transaction nt
                                                            join new_Account na on nt."accountId" = na.id
                                                            join "SCHEMA"."Account" a on na.id = a.id
                                                            join new_Category nc on nt."categoryId" = nc.id
                                                            join "SCHEMA"."Category" c on nc.id = c.id;`);
    console.log(tx);
    console.log(`Seeding finished.`);
}

main()
    .catch((e) => {
        console.error(e)
        process.exit(1)
    })
    .finally(async () => {
        await prisma.$disconnect()
    });
