const { gql } = require("apollo-server");
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export const typeDefs = gql`
type Transaction {
    id: ID!,
    account: Account,
    accountId: String,
    category: Category,
    categoryId: String,
    reference: String,
    amount: Float,
    currency: String,
    date: String
}
type Account {
    id: ID!,
    name: String!
}
type Category {
    id: ID!,
    name: String!,
    color: String
}
type Query {
    transactions(skip: Int, take: Int, searchId: String, startDate: String, endDate: String, sort: String): [Transaction!],
    accounts: [Account!],
}
`;

// GraphQL Queries

export const resolvers = {
    Query: {
        transactions: (parent: any, args: any) => {
            return prisma.transaction.findMany({
                skip: args.skip,
                take: args.take,
                include: {
                    account: true,
                    category: true,
                },
                where: {
                    accountId: args.searchId,
                    date: {
                        gte: args.startDate,
                        lte: args.endDate,
                    }
                },
                orderBy: {
                    date: args.sort
                }
            });
        },
        accounts: (parent: any, args: any) => {
            return prisma.account.findMany({});
        },
    }
}
