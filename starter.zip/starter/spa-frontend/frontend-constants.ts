export const DEFAULT_BATCH_SIZE = 25;
