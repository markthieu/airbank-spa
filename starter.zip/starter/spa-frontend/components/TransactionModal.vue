<template>
  <div class="modal-overlay text-sm" @click="$emit('close-modal')">
    <div class="flex modal flex-col">
      <div class="pb-6 -mt-8 flex justify-center">
        <span class="font-semibold text-l absolute">Transaction Details</span>
        <button class="text-xs ml-auto order-2 pr-11 font-mono float-right" @click="$emit('close-modal')">X</button>
      </div>
      <hr/>
      <div class="flex flex-row items-center justify-start">
      <div class="flex flex-row justify-evenly w-3/6 items-center">
        <div class="flex flex-col justify-evenly h-40">
          <span>Account name: </span>
          <span>Category: </span>
          <span>Date: </span>
        </div>
        <div class="flex flex-col justify-evenly h-40">
          <span>{{ txData?.account.name }}</span>
          <div
            class="rounded p-0.5 opacity-60"
            :style="{ 'background-color': '#' + txData?.category.color }">
            <span class="px-1 text-black opacity-100">{{
              txData?.category.name
            }}</span>
          </div>
          <span>{{ txDate }}</span>
        </div>
      </div>
      <div class="flex flex-col w-3/6 h-full pt-6">
          <div class="self-start">Reference: </div>
          <div class="w-11/12 h-4/5 bg-gray-100 rounded text-start">
            <span v-if="!!txData?.reference">{{txData?.reference}}</span>
            <span class="text-gray-400" v-else="!!txData?.reference">No reference provided</span>

          </div>
      </div>
      </div>
      <hr/>
      <div class="text-end pt-5 pr-10">
        <span>Amount: </span>
        <span>{{ txData?.amount }}</span>
        <span class="text-gray-400">{{ txData?.currency }}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['txData', 'txDate'],
  name: 'TransactionModal',
}
</script>

<style scoped></style>
