<template>
  <!-- Page -->
  <div class="flex bg-gray-100 top-0 bottom-0 left-0 right-0 justify-center">
    <!-- Card -->
    <div
      class="flex flex-col rounded pt-5 bg-white my-5 w-5/6 shadow-2xl overflow-scroll">
      <h1 class="font-bold pl-5 pb-5">Transactions</h1>
      <div
        class="flex flex-row justify-between items-center pl-7 max-w-2xl text-gray-400 text-s">
        <div class="flex flex-col">
          <span>Account</span>
          <select id="accounts"
            class="border w-40"
            v-on:click="loadAccounts()"
            v-on:change="setFilterId($event)">
            <option value="none">No filter</option>
            <option
              v-for="account in accounts"
              :key="account.id"
              :value="account.id">
              {{ account.name }}
            </option>
          </select>
        </div>
        <div class="flex flex-col">
          <span>Starting month</span>
          <input id="startDate"
            class="border w-30"
            type="date"
            v-on:change="setDate('start', $event)" />
        </div>
        <span class="pt-6"> - </span>
        <div class="flex flex-col">
          <span>Ending month</span>
          <input id="endDate"
            class="border w-30"
            type="date"
            v-on:change="setDate('end', $event)" />
        </div>
        <div class="mt-6 h-7 rounded bg-gray-300 hover:opacity-40 border border-black">
          <button class=" text-sm px-1 text-black" v-on:click="resetFilters()">
            Reset filters
          </button>
        </div>
      </div>
      <!-- Table -->
      <div class="p-7">
        <!-- Headers -->
        <div class="flex justify-between w-full border-b-2 border-t-2 pt-2 pb-2 text-gray-400 text-sm">
          <span>Reference</span>
          <div class="flex justify-between w-3/5">
            <span>Category</span>
            <div class="lg:-ml-24 2xl:-ml-52 flex items-center hover:opacity-40"
              v-on:click="reverseDateSort()">
              <span>Date</span>
              <div class="pl-2">
                <div v-if="sort === 'asc'" class="up-arrow"></div>
                <div v-if="sort === 'desc'" class="down-arrow"></div>
              </div>
            </div>
            <span>Amount</span>
          </div>
        </div>
        <!-- List items -->
        <div
          class="hover:bg-gray-200 flex justify-between w-full pb-1 pt-1 border-b whitespace-nowrap text-sm"
          v-for="transaction in transactions"
          :key="transaction.id"
          v-on:click="showTransaction(transaction)">
          <span v-if="!!transaction.reference">{{
            transaction?.reference
          }}</span>
          <span class="text-gray-400" v-else="!!transaction.reference">
            No reference provided
          </span>
          <div class="flex justify-between w-3/5">
            <div
              class="rounded p-0.5 opacity-60 bg-gray-400"
              :style="{ 'background-color': '#' + transaction?.category.color }">
              <span class="px-1 text-xs font-semibold text-black opacity-100">{{
                transaction?.category.name
              }}</span>
            </div>
            <div class="flex justify-between w-3/5 items-center">
              <span class="text-xs">{{ getDate(transaction?.date) }}</span>
              <div>
                <span>{{ transaction?.amount }}.00</span>
                <span class="text-gray-400">{{ transaction?.currency }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="flex items-center p-7 justify-between">
        <div class="flex w-2/12">
          <div class="flex justify-center bg-gray-300 w-14 hover:opacity-40 rounded border border-black mr-1">
            <button class="p-1" v-on:click="fetchNextBatch(false)">Back</button>
          </div>
          <div class="flex justify-center bg-gray-300 w-14 hover:opacity-40 rounded border border-black">
            <button class="p-1" v-on:click="fetchNextBatch(true)">Next</button>
          </div>
        </div>
        <span>Page: {{ pageNumber }}</span>
      </div>
      <transaction-modal
        :txData="txData"
        :txDate="txDate"
        v-show="showTransactionModal"
        @close-modal="showTransactionModal = false" />
    </div>
  </div>
</template>

<script>
import transactions from '~/queries/allTransactions.gql'
import accounts from '~/queries/allAccounts.gql'
import { DEFAULT_BATCH_SIZE } from '~/frontend-constants'

export default {
  data() {
    return {
      txData: null,
      txDate: null,
      showTransactionModal: false,
      pageNumber: 1,
      transactions: [],
      accounts: [],
      idFilter: undefined,
      startDate: undefined,
      endDate: undefined,
      sort: 'desc',
    }
  },
  apollo: {
    transactions: {
      prefetch: true,
      query: transactions,
      variables() {
        return {
          skip: (this.pageNumber - 1) * DEFAULT_BATCH_SIZE,
          take: DEFAULT_BATCH_SIZE,
          searchId: this.idFilter,
          startDate: this.startDate,
          endDate: this.endDate,
          sort: this.sort,
        }
      },
    },
  },
  methods: {
    fetchNextBatch(forward) {
      // Can't go back from page 1
      if (!forward && this.pageNumber <= 1) {
        return;
      }
      // Don't go forward if no more tx left
      if (forward && this.transactions.length < DEFAULT_BATCH_SIZE) {
        return;
      }
      forward ? (this.pageNumber += 1) : (this.pageNumber -= 1);
    },
    getDate(date) {
      let new_date = new Date(JSON.parse(date))
      return new_date.toLocaleDateString()
    },
    loadAccounts() {
      if (this.accounts.length === 0) {
        this.$apollo
          .query({
            query: accounts,
          })
          .then((result) => {
            this.accounts = result.data.accounts
          })
      }
    },
    resetFilters() {
      document.getElementById("startDate").value = "";
      document.getElementById("endDate").value = "";
      document.getElementById("accounts").value = "none";
      this.pageNumber = 1;
      this.idFilter = undefined;
      this.startDate = undefined;
      this.endDate = undefined;
    },
    setDate(name, event) {
      name === 'start'
        ? (this.startDate = new Date(event.target.value))
        : (this.endDate = new Date(event.target.value))
    },
    setFilterId(event) {
      if (event.target.value === 'none') {
        this.idFilter = undefined
      } else {
        this.pageNumber = 1
        this.idFilter = event.target.value
      }
    },
    reverseDateSort() {
      this.sort === 'desc' ? (this.sort = 'asc') : (this.sort = 'desc')
    },
    showTransaction(transaction) {
      this.txData = transaction
      this.txDate = this.getDate(transaction.date)
      this.showTransactionModal = true
    },
  },
  name: 'IndexPage',
}
</script>
